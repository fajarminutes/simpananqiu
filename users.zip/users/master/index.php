<?php 
session_start();
 // Alihkan pengguna ke halaman login
header("Location: k_s.php");
?>